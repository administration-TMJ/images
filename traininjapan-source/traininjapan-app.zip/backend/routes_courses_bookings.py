# This will be imported into server.py - contains Course, Booking, Payment routes
# Due to size, splitting into modules
